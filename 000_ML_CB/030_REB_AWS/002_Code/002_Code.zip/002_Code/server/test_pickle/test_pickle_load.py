import pickle as pkl
# We have four functions in pickle
# 1. pickle.dump()
# 2. pickle.load()


file_name = 'file_name.pkl'
file = open (file_name, 'wb')
pkl.dump ("Peter", file)
file.close()
file = open (file_name, 'rb')
boy_name = pkl.load(file)
print('boy_name:', boy_name)
file.close()