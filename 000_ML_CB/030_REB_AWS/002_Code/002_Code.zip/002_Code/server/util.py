import pickle
import json
import numpy as np
#from sklearn.linear_model import base
#from sklearn.linear_model import _base

__locations = None
__data_columns = None
__model = None

def get_estimated_price(location,sqft,bhk,bath):
    try:
        loc_index = __data_columns.index(location.lower())
    except:
        loc_index = -1

    x = np.zeros(len(__data_columns))
    #print('*****location********:', location)  # *****location********: Kalhali
    #print('==== sqst====:', sqft)              # ==== sqst====: 1000
    #print('==== bath====:', bath)              # ==== bath====: 2
    #print('==== bhk=====:', bhk)               # ==== bhk=====: 2

    x[0] = sqft
    x[1] = bath
    x[2] = bhk
    if loc_index>=0:
        x[loc_index] = 1
    #print('-----len(x)----:', len(x))   # -----len(x)----: 243
    #print('-----[x]----:', [x])         # ----[x]----: [array([1000.,    2.,    2.,    0.,.0.])]
    #print('-----[x][0]----:', [x][0])   # -----[x][0]----: [1000.    2.    2.    0. ..., 0.]

    pred_res = round(__model.predict([x])[0],2)
    # print('----- pred_res----:', pred_res)  # ----- pred_res----: 86.08
    return pred_res
    #return round(__model.predict([x])[0],2)


def load_saved_artifacts():
    print("loading saved artifacts...start")
    global  __data_columns
    global __locations

    with open("./artifacts/columns.json", "r") as f:
        __data_columns = json.load(f)['data_columns']
        __locations = __data_columns[3:]  # first 3 columns are sqft, bath, bhk

    global __model
    if __model is None:
        f1 = open('./artifacts/banglore_home_prices_model.pickle', 'rb')
        __model = pickle.load(f1)

        with open('./artifacts/banglore_home_prices_model.pickle', 'rb') as f:
            __model = pickle.load(f)
            #__model = pickle.loads(f)
    print("loading saved artifacts...done")

def get_location_names():
    return __locations

def get_data_columns():
    return __data_columns

if __name__ == '__main__':
    load_saved_artifacts()
    #print(get_location_names())
    print("Test Util results:")
    util_result1 = get_estimated_price('1st Phase JP Nagar',1000, 3, 3)
    util_result2 = get_estimated_price('1st Pjase JP Negdar', 1000, 2, 2)
    util_result3 = get_estimated_price('Kalhali', 1000, 2, 2) # Other location
    util_result4 = get_estimated_price('Ejipura', 1000, 2, 2) # Other location
    print("util_result1:", util_result1)
    print("util_result2:", util_result2)
    print("util_result3:", util_result3)
    print("util_result4:", util_result4)