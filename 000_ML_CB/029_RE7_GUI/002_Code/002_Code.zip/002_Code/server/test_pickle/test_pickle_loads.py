import pickle
# We have four functions in pickle
# 1. pickle.dump()
# 2. pickle.load()
# 3. pickle.dumps()
# 4. pickle.loads()

class exmaple_class:
    a_number = 35
    a_string = "hey"
    a_lst = [1, 2, 3]
    a_dict = {"first": "a", "second": 2, "third": [1, 2, 3]}
    a_tuple = (22, 23) 

my_object = exmaple_class()

my_pickled_object = pickle.dumps(my_object) # Change into serial object
print(f"This is my picked object:\n{my_pickled_object}\n")

my_object.a_dict = None

my_unpickled_object = pickle.loads(my_pickled_object)
print(
    f"a_dict of unpickled object:\n{my_unpickled_object.a_dict}\n"
    )